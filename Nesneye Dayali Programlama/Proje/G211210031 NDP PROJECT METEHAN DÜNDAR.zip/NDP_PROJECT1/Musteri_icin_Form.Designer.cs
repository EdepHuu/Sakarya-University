﻿
namespace NDP_PROJECT1
{
    partial class Musteri_icin_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.lblErkek = new System.Windows.Forms.Label();
            this.lblCocuk = new System.Windows.Forms.Label();
            this.lblKadin = new System.Windows.Forms.Label();
            this.lblTshirtt = new System.Windows.Forms.Label();
            this.lblSweatshirtt = new System.Windows.Forms.Label();
            this.lblPantolonn = new System.Windows.Forms.Label();
            this.lblstok1 = new System.Windows.Forms.Label();
            this.lblSiparis1 = new System.Windows.Forms.Label();
            this.lblstok2 = new System.Windows.Forms.Label();
            this.lblSiparis2 = new System.Windows.Forms.Label();
            this.lblstok3 = new System.Windows.Forms.Label();
            this.lblSiparis3 = new System.Windows.Forms.Label();
            this.lbl_Erkek_Ts_Stok = new System.Windows.Forms.Label();
            this.lbl_Erkek_P_Stok = new System.Windows.Forms.Label();
            this.lbl_Erkek_STs_Stok = new System.Windows.Forms.Label();
            this.lbl_Kadin_Ts_Stok = new System.Windows.Forms.Label();
            this.lbl_Kadin_P_Stok = new System.Windows.Forms.Label();
            this.lbl_Kadin_STs_Stok = new System.Windows.Forms.Label();
            this.lbl_Cocuk_Ts_Stok = new System.Windows.Forms.Label();
            this.lbl_Cocuk_P_Stok = new System.Windows.Forms.Label();
            this.lbl_Cocuk_STs_Stok = new System.Windows.Forms.Label();
            this.txt_Erkek_Ts_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Erkek_P_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Erkek_STs_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Kadin_Ts_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Kadin_P_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Kadin_STs_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_Ts_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_P_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_STs_Siparis = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("SimSun-ExtB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(438, 421);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(201, 83);
            this.button1.TabIndex = 0;
            this.button1.Text = "Siparis Ver";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblErkek
            // 
            this.lblErkek.AutoSize = true;
            this.lblErkek.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblErkek.Location = new System.Drawing.Point(230, 9);
            this.lblErkek.Name = "lblErkek";
            this.lblErkek.Size = new System.Drawing.Size(180, 60);
            this.lblErkek.TabIndex = 1;
            this.lblErkek.Text = "ERKEK";
            this.lblErkek.Click += new System.EventHandler(this.lblerkek_Click);
            // 
            // lblCocuk
            // 
            this.lblCocuk.AutoSize = true;
            this.lblCocuk.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCocuk.Location = new System.Drawing.Point(670, 9);
            this.lblCocuk.Name = "lblCocuk";
            this.lblCocuk.Size = new System.Drawing.Size(180, 60);
            this.lblCocuk.TabIndex = 2;
            this.lblCocuk.Text = "ÇOCUK";
            this.lblCocuk.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblKadin
            // 
            this.lblKadin.AutoSize = true;
            this.lblKadin.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblKadin.Location = new System.Drawing.Point(450, 9);
            this.lblKadin.Name = "lblKadin";
            this.lblKadin.Size = new System.Drawing.Size(180, 60);
            this.lblKadin.TabIndex = 3;
            this.lblKadin.Text = "KADIN";
            // 
            // lblTshirtt
            // 
            this.lblTshirtt.AutoSize = true;
            this.lblTshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTshirtt.Location = new System.Drawing.Point(13, 134);
            this.lblTshirtt.Name = "lblTshirtt";
            this.lblTshirtt.Size = new System.Drawing.Size(124, 41);
            this.lblTshirtt.TabIndex = 4;
            this.lblTshirtt.Text = "T-SHIRT";
            // 
            // lblSweatshirtt
            // 
            this.lblSweatshirtt.AutoSize = true;
            this.lblSweatshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSweatshirtt.Location = new System.Drawing.Point(13, 334);
            this.lblSweatshirtt.Name = "lblSweatshirtt";
            this.lblSweatshirtt.Size = new System.Drawing.Size(187, 41);
            this.lblSweatshirtt.TabIndex = 5;
            this.lblSweatshirtt.Text = "SWEATSHIRT";
            // 
            // lblPantolonn
            // 
            this.lblPantolonn.AutoSize = true;
            this.lblPantolonn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPantolonn.Location = new System.Drawing.Point(12, 234);
            this.lblPantolonn.Name = "lblPantolonn";
            this.lblPantolonn.Size = new System.Drawing.Size(170, 41);
            this.lblPantolonn.TabIndex = 6;
            this.lblPantolonn.Text = "PANTOLON";
            this.lblPantolonn.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblstok1
            // 
            this.lblstok1.AutoSize = true;
            this.lblstok1.Location = new System.Drawing.Point(230, 83);
            this.lblstok1.Name = "lblstok1";
            this.lblstok1.Size = new System.Drawing.Size(79, 20);
            this.lblstok1.TabIndex = 7;
            this.lblstok1.Text = "Stok Sayisi";
            // 
            // lblSiparis1
            // 
            this.lblSiparis1.AutoSize = true;
            this.lblSiparis1.Location = new System.Drawing.Point(307, 83);
            this.lblSiparis1.Name = "lblSiparis1";
            this.lblSiparis1.Size = new System.Drawing.Size(103, 20);
            this.lblSiparis1.TabIndex = 8;
            this.lblSiparis1.Text = "Siparis Sayiniz";
            this.lblSiparis1.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblstok2
            // 
            this.lblstok2.AutoSize = true;
            this.lblstok2.Location = new System.Drawing.Point(450, 83);
            this.lblstok2.Name = "lblstok2";
            this.lblstok2.Size = new System.Drawing.Size(79, 20);
            this.lblstok2.TabIndex = 9;
            this.lblstok2.Text = "Stok Sayisi";
            // 
            // lblSiparis2
            // 
            this.lblSiparis2.AutoSize = true;
            this.lblSiparis2.Location = new System.Drawing.Point(527, 83);
            this.lblSiparis2.Name = "lblSiparis2";
            this.lblSiparis2.Size = new System.Drawing.Size(103, 20);
            this.lblSiparis2.TabIndex = 10;
            this.lblSiparis2.Text = "Siparis Sayiniz";
            // 
            // lblstok3
            // 
            this.lblstok3.AutoSize = true;
            this.lblstok3.Location = new System.Drawing.Point(670, 83);
            this.lblstok3.Name = "lblstok3";
            this.lblstok3.Size = new System.Drawing.Size(79, 20);
            this.lblstok3.TabIndex = 11;
            this.lblstok3.Text = "Stok Sayisi";
            // 
            // lblSiparis3
            // 
            this.lblSiparis3.AutoSize = true;
            this.lblSiparis3.Location = new System.Drawing.Point(747, 83);
            this.lblSiparis3.Name = "lblSiparis3";
            this.lblSiparis3.Size = new System.Drawing.Size(103, 20);
            this.lblSiparis3.TabIndex = 12;
            this.lblSiparis3.Text = "Siparis Sayiniz";
            // 
            // lbl_Erkek_Ts_Stok
            // 
            this.lbl_Erkek_Ts_Stok.AutoSize = true;
            this.lbl_Erkek_Ts_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Erkek_Ts_Stok.Location = new System.Drawing.Point(230, 144);
            this.lbl_Erkek_Ts_Stok.Name = "lbl_Erkek_Ts_Stok";
            this.lbl_Erkek_Ts_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Erkek_Ts_Stok.TabIndex = 13;
            this.lbl_Erkek_Ts_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Erkek_P_Stok
            // 
            this.lbl_Erkek_P_Stok.AutoSize = true;
            this.lbl_Erkek_P_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Erkek_P_Stok.Location = new System.Drawing.Point(230, 244);
            this.lbl_Erkek_P_Stok.Name = "lbl_Erkek_P_Stok";
            this.lbl_Erkek_P_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Erkek_P_Stok.TabIndex = 14;
            this.lbl_Erkek_P_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Erkek_STs_Stok
            // 
            this.lbl_Erkek_STs_Stok.AutoSize = true;
            this.lbl_Erkek_STs_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Erkek_STs_Stok.Location = new System.Drawing.Point(230, 344);
            this.lbl_Erkek_STs_Stok.Name = "lbl_Erkek_STs_Stok";
            this.lbl_Erkek_STs_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Erkek_STs_Stok.TabIndex = 15;
            this.lbl_Erkek_STs_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Kadin_Ts_Stok
            // 
            this.lbl_Kadin_Ts_Stok.AutoSize = true;
            this.lbl_Kadin_Ts_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Kadin_Ts_Stok.Location = new System.Drawing.Point(450, 144);
            this.lbl_Kadin_Ts_Stok.Name = "lbl_Kadin_Ts_Stok";
            this.lbl_Kadin_Ts_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Kadin_Ts_Stok.TabIndex = 16;
            this.lbl_Kadin_Ts_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Kadin_P_Stok
            // 
            this.lbl_Kadin_P_Stok.AutoSize = true;
            this.lbl_Kadin_P_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Kadin_P_Stok.Location = new System.Drawing.Point(450, 244);
            this.lbl_Kadin_P_Stok.Name = "lbl_Kadin_P_Stok";
            this.lbl_Kadin_P_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Kadin_P_Stok.TabIndex = 17;
            this.lbl_Kadin_P_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Kadin_STs_Stok
            // 
            this.lbl_Kadin_STs_Stok.AutoSize = true;
            this.lbl_Kadin_STs_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Kadin_STs_Stok.Location = new System.Drawing.Point(450, 344);
            this.lbl_Kadin_STs_Stok.Name = "lbl_Kadin_STs_Stok";
            this.lbl_Kadin_STs_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Kadin_STs_Stok.TabIndex = 18;
            this.lbl_Kadin_STs_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Cocuk_Ts_Stok
            // 
            this.lbl_Cocuk_Ts_Stok.AutoSize = true;
            this.lbl_Cocuk_Ts_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cocuk_Ts_Stok.Location = new System.Drawing.Point(670, 144);
            this.lbl_Cocuk_Ts_Stok.Name = "lbl_Cocuk_Ts_Stok";
            this.lbl_Cocuk_Ts_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Cocuk_Ts_Stok.TabIndex = 19;
            this.lbl_Cocuk_Ts_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Cocuk_P_Stok
            // 
            this.lbl_Cocuk_P_Stok.AutoSize = true;
            this.lbl_Cocuk_P_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cocuk_P_Stok.Location = new System.Drawing.Point(670, 244);
            this.lbl_Cocuk_P_Stok.Name = "lbl_Cocuk_P_Stok";
            this.lbl_Cocuk_P_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Cocuk_P_Stok.TabIndex = 20;
            this.lbl_Cocuk_P_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Cocuk_STs_Stok
            // 
            this.lbl_Cocuk_STs_Stok.AutoSize = true;
            this.lbl_Cocuk_STs_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cocuk_STs_Stok.Location = new System.Drawing.Point(670, 344);
            this.lbl_Cocuk_STs_Stok.Name = "lbl_Cocuk_STs_Stok";
            this.lbl_Cocuk_STs_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Cocuk_STs_Stok.TabIndex = 21;
            this.lbl_Cocuk_STs_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Erkek_Ts_Siparis
            // 
            this.txt_Erkek_Ts_Siparis.Location = new System.Drawing.Point(307, 144);
            this.txt_Erkek_Ts_Siparis.Name = "txt_Erkek_Ts_Siparis";
            this.txt_Erkek_Ts_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Erkek_Ts_Siparis.TabIndex = 22;
            this.txt_Erkek_Ts_Siparis.Text = "0";
            this.txt_Erkek_Ts_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_Erkek_Ts_Siparis.TextChanged += new System.EventHandler(this.txt_Erkek_Ts_Siparis_TextChanged);
            // 
            // txt_Erkek_P_Siparis
            // 
            this.txt_Erkek_P_Siparis.Location = new System.Drawing.Point(307, 244);
            this.txt_Erkek_P_Siparis.Name = "txt_Erkek_P_Siparis";
            this.txt_Erkek_P_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Erkek_P_Siparis.TabIndex = 23;
            this.txt_Erkek_P_Siparis.Text = "0";
            this.txt_Erkek_P_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Erkek_STs_Siparis
            // 
            this.txt_Erkek_STs_Siparis.Location = new System.Drawing.Point(307, 344);
            this.txt_Erkek_STs_Siparis.Name = "txt_Erkek_STs_Siparis";
            this.txt_Erkek_STs_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Erkek_STs_Siparis.TabIndex = 24;
            this.txt_Erkek_STs_Siparis.Text = "0";
            this.txt_Erkek_STs_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_Ts_Siparis
            // 
            this.txt_Kadin_Ts_Siparis.Location = new System.Drawing.Point(527, 144);
            this.txt_Kadin_Ts_Siparis.Name = "txt_Kadin_Ts_Siparis";
            this.txt_Kadin_Ts_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Kadin_Ts_Siparis.TabIndex = 25;
            this.txt_Kadin_Ts_Siparis.Text = "0";
            this.txt_Kadin_Ts_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_P_Siparis
            // 
            this.txt_Kadin_P_Siparis.Location = new System.Drawing.Point(527, 244);
            this.txt_Kadin_P_Siparis.Name = "txt_Kadin_P_Siparis";
            this.txt_Kadin_P_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Kadin_P_Siparis.TabIndex = 26;
            this.txt_Kadin_P_Siparis.Text = "0";
            this.txt_Kadin_P_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_STs_Siparis
            // 
            this.txt_Kadin_STs_Siparis.Location = new System.Drawing.Point(527, 345);
            this.txt_Kadin_STs_Siparis.Name = "txt_Kadin_STs_Siparis";
            this.txt_Kadin_STs_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Kadin_STs_Siparis.TabIndex = 27;
            this.txt_Kadin_STs_Siparis.Text = "0";
            this.txt_Kadin_STs_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_Kadin_STs_Siparis.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txt_Cocuk_Ts_Siparis
            // 
            this.txt_Cocuk_Ts_Siparis.Location = new System.Drawing.Point(747, 145);
            this.txt_Cocuk_Ts_Siparis.Name = "txt_Cocuk_Ts_Siparis";
            this.txt_Cocuk_Ts_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Cocuk_Ts_Siparis.TabIndex = 28;
            this.txt_Cocuk_Ts_Siparis.Text = "0";
            this.txt_Cocuk_Ts_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_P_Siparis
            // 
            this.txt_Cocuk_P_Siparis.Location = new System.Drawing.Point(747, 244);
            this.txt_Cocuk_P_Siparis.Name = "txt_Cocuk_P_Siparis";
            this.txt_Cocuk_P_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Cocuk_P_Siparis.TabIndex = 29;
            this.txt_Cocuk_P_Siparis.Text = "0";
            this.txt_Cocuk_P_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_STs_Siparis
            // 
            this.txt_Cocuk_STs_Siparis.Location = new System.Drawing.Point(747, 344);
            this.txt_Cocuk_STs_Siparis.Name = "txt_Cocuk_STs_Siparis";
            this.txt_Cocuk_STs_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Cocuk_STs_Siparis.TabIndex = 30;
            this.txt_Cocuk_STs_Siparis.Text = "0";
            this.txt_Cocuk_STs_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_Cocuk_STs_Siparis.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // Musteri_icin_Form
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1171, 553);
            this.Controls.Add(this.txt_Cocuk_STs_Siparis);
            this.Controls.Add(this.txt_Cocuk_P_Siparis);
            this.Controls.Add(this.txt_Cocuk_Ts_Siparis);
            this.Controls.Add(this.txt_Kadin_STs_Siparis);
            this.Controls.Add(this.txt_Kadin_P_Siparis);
            this.Controls.Add(this.txt_Kadin_Ts_Siparis);
            this.Controls.Add(this.txt_Erkek_STs_Siparis);
            this.Controls.Add(this.txt_Erkek_P_Siparis);
            this.Controls.Add(this.txt_Erkek_Ts_Siparis);
            this.Controls.Add(this.lbl_Cocuk_STs_Stok);
            this.Controls.Add(this.lbl_Cocuk_P_Stok);
            this.Controls.Add(this.lbl_Cocuk_Ts_Stok);
            this.Controls.Add(this.lbl_Kadin_STs_Stok);
            this.Controls.Add(this.lbl_Kadin_P_Stok);
            this.Controls.Add(this.lbl_Kadin_Ts_Stok);
            this.Controls.Add(this.lbl_Erkek_STs_Stok);
            this.Controls.Add(this.lbl_Erkek_P_Stok);
            this.Controls.Add(this.lbl_Erkek_Ts_Stok);
            this.Controls.Add(this.lblSiparis3);
            this.Controls.Add(this.lblstok3);
            this.Controls.Add(this.lblSiparis2);
            this.Controls.Add(this.lblstok2);
            this.Controls.Add(this.lblSiparis1);
            this.Controls.Add(this.lblstok1);
            this.Controls.Add(this.lblPantolonn);
            this.Controls.Add(this.lblSweatshirtt);
            this.Controls.Add(this.lblTshirtt);
            this.Controls.Add(this.lblKadin);
            this.Controls.Add(this.lblCocuk);
            this.Controls.Add(this.lblErkek);
            this.Controls.Add(this.button1);
            this.Name = "Musteri_icin_Form";
            this.Text = "Alisveris Sayfasi";
            this.Load += new System.EventHandler(this.Musteri_icin_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label lblErkek;
        public System.Windows.Forms.Label lblCocuk;
        public System.Windows.Forms.Label lblKadin;
        public System.Windows.Forms.Label lblTshirtt;
        public System.Windows.Forms.Label lblSweatshirtt;
        public System.Windows.Forms.Label lblPantolonn;
        public System.Windows.Forms.Label lblstok1;
        public System.Windows.Forms.Label lblSiparis1;
        public System.Windows.Forms.Label lblstok2;
        public System.Windows.Forms.Label lblSiparis2;
        public System.Windows.Forms.Label lblstok3;
        public System.Windows.Forms.Label lblSiparis3;
        public System.Windows.Forms.Label lbl_Erkek_Ts_Stok;
        public System.Windows.Forms.Label lbl_Erkek_P_Stok;
        public System.Windows.Forms.Label lbl_Erkek_STs_Stok;
        public System.Windows.Forms.Label lbl_Kadin_Ts_Stok;
        public System.Windows.Forms.Label lbl_Kadin_P_Stok;
        public System.Windows.Forms.Label lbl_Kadin_STs_Stok;
        public System.Windows.Forms.Label lbl_Cocuk_Ts_Stok;
        public System.Windows.Forms.Label lbl_Cocuk_P_Stok;
        public System.Windows.Forms.Label lbl_Cocuk_STs_Stok;
        public System.Windows.Forms.TextBox txt_Erkek_Ts_Siparis;
        public System.Windows.Forms.TextBox txt_Erkek_P_Siparis;
        public System.Windows.Forms.TextBox txt_Erkek_STs_Siparis;
        public System.Windows.Forms.TextBox txt_Kadin_Ts_Siparis;
        public System.Windows.Forms.TextBox txt_Kadin_P_Siparis;
        public System.Windows.Forms.TextBox txt_Kadin_STs_Siparis;
        public System.Windows.Forms.TextBox txt_Cocuk_Ts_Siparis;
        public System.Windows.Forms.TextBox txt_Cocuk_P_Siparis;
        public System.Windows.Forms.TextBox txt_Cocuk_STs_Siparis;
    }
}