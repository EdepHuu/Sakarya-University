﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NDP_PROJECT1
{
    public partial class DepodakiStokForm : Form
    {
        public DepodakiStokForm()
        {
            InitializeComponent();
        }

        private void RaftakiStokForm_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
