﻿
namespace NDP_PROJECT1
{
    partial class RafdakiStokForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPantolonn = new System.Windows.Forms.Label();
            this.lblSweatshirtt = new System.Windows.Forms.Label();
            this.lblTshirtt = new System.Windows.Forms.Label();
            this.lblKadin = new System.Windows.Forms.Label();
            this.lblCocuk = new System.Windows.Forms.Label();
            this.lblErkek = new System.Windows.Forms.Label();
            this.txt_Erkek_Ts_stok = new System.Windows.Forms.TextBox();
            this.txt_Kadin_P_stok = new System.Windows.Forms.TextBox();
            this.txt_Kadin_Ts_stok = new System.Windows.Forms.TextBox();
            this.txt_Erkek_STs_stok = new System.Windows.Forms.TextBox();
            this.txt_Erkek_P_stok = new System.Windows.Forms.TextBox();
            this.txt_Kadin_STs_stok = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_Ts_stok = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_P_stok = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_STs_stok = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblPantolonn
            // 
            this.lblPantolonn.AutoSize = true;
            this.lblPantolonn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPantolonn.Location = new System.Drawing.Point(56, 255);
            this.lblPantolonn.Name = "lblPantolonn";
            this.lblPantolonn.Size = new System.Drawing.Size(170, 41);
            this.lblPantolonn.TabIndex = 36;
            this.lblPantolonn.Text = "PANTOLON";
            // 
            // lblSweatshirtt
            // 
            this.lblSweatshirtt.AutoSize = true;
            this.lblSweatshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSweatshirtt.Location = new System.Drawing.Point(57, 355);
            this.lblSweatshirtt.Name = "lblSweatshirtt";
            this.lblSweatshirtt.Size = new System.Drawing.Size(187, 41);
            this.lblSweatshirtt.TabIndex = 35;
            this.lblSweatshirtt.Text = "SWEATSHIRT";
            // 
            // lblTshirtt
            // 
            this.lblTshirtt.AutoSize = true;
            this.lblTshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTshirtt.Location = new System.Drawing.Point(57, 155);
            this.lblTshirtt.Name = "lblTshirtt";
            this.lblTshirtt.Size = new System.Drawing.Size(124, 41);
            this.lblTshirtt.TabIndex = 34;
            this.lblTshirtt.Text = "T-SHIRT";
            // 
            // lblKadin
            // 
            this.lblKadin.AutoSize = true;
            this.lblKadin.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblKadin.Location = new System.Drawing.Point(494, 30);
            this.lblKadin.Name = "lblKadin";
            this.lblKadin.Size = new System.Drawing.Size(180, 60);
            this.lblKadin.TabIndex = 33;
            this.lblKadin.Text = "KADIN";
            this.lblKadin.Click += new System.EventHandler(this.lblKadin_Click);
            // 
            // lblCocuk
            // 
            this.lblCocuk.AutoSize = true;
            this.lblCocuk.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCocuk.Location = new System.Drawing.Point(714, 30);
            this.lblCocuk.Name = "lblCocuk";
            this.lblCocuk.Size = new System.Drawing.Size(180, 60);
            this.lblCocuk.TabIndex = 32;
            this.lblCocuk.Text = "ÇOCUK";
            // 
            // lblErkek
            // 
            this.lblErkek.AutoSize = true;
            this.lblErkek.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblErkek.Location = new System.Drawing.Point(274, 30);
            this.lblErkek.Name = "lblErkek";
            this.lblErkek.Size = new System.Drawing.Size(180, 60);
            this.lblErkek.TabIndex = 31;
            this.lblErkek.Text = "ERKEK";
            // 
            // txt_Erkek_Ts_stok
            // 
            this.txt_Erkek_Ts_stok.Location = new System.Drawing.Point(274, 155);
            this.txt_Erkek_Ts_stok.Name = "txt_Erkek_Ts_stok";
            this.txt_Erkek_Ts_stok.ReadOnly = true;
            this.txt_Erkek_Ts_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Erkek_Ts_stok.TabIndex = 37;
            this.txt_Erkek_Ts_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_Erkek_Ts_stok.TextChanged += new System.EventHandler(this.txt_Erkek_Ts_stok_TextChanged);
            // 
            // txt_Kadin_P_stok
            // 
            this.txt_Kadin_P_stok.Location = new System.Drawing.Point(494, 269);
            this.txt_Kadin_P_stok.Name = "txt_Kadin_P_stok";
            this.txt_Kadin_P_stok.ReadOnly = true;
            this.txt_Kadin_P_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Kadin_P_stok.TabIndex = 38;
            this.txt_Kadin_P_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_Ts_stok
            // 
            this.txt_Kadin_Ts_stok.Location = new System.Drawing.Point(494, 155);
            this.txt_Kadin_Ts_stok.Name = "txt_Kadin_Ts_stok";
            this.txt_Kadin_Ts_stok.ReadOnly = true;
            this.txt_Kadin_Ts_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Kadin_Ts_stok.TabIndex = 39;
            this.txt_Kadin_Ts_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_Kadin_Ts_stok.TextChanged += new System.EventHandler(this.texttxt_Kadin_Ts_stokBox7_TextChanged);
            // 
            // txt_Erkek_STs_stok
            // 
            this.txt_Erkek_STs_stok.Location = new System.Drawing.Point(274, 369);
            this.txt_Erkek_STs_stok.Name = "txt_Erkek_STs_stok";
            this.txt_Erkek_STs_stok.ReadOnly = true;
            this.txt_Erkek_STs_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Erkek_STs_stok.TabIndex = 40;
            this.txt_Erkek_STs_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Erkek_P_stok
            // 
            this.txt_Erkek_P_stok.Location = new System.Drawing.Point(274, 269);
            this.txt_Erkek_P_stok.Name = "txt_Erkek_P_stok";
            this.txt_Erkek_P_stok.ReadOnly = true;
            this.txt_Erkek_P_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Erkek_P_stok.TabIndex = 41;
            this.txt_Erkek_P_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_STs_stok
            // 
            this.txt_Kadin_STs_stok.Location = new System.Drawing.Point(494, 369);
            this.txt_Kadin_STs_stok.Name = "txt_Kadin_STs_stok";
            this.txt_Kadin_STs_stok.ReadOnly = true;
            this.txt_Kadin_STs_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Kadin_STs_stok.TabIndex = 42;
            this.txt_Kadin_STs_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_Ts_stok
            // 
            this.txt_Cocuk_Ts_stok.Location = new System.Drawing.Point(714, 155);
            this.txt_Cocuk_Ts_stok.Name = "txt_Cocuk_Ts_stok";
            this.txt_Cocuk_Ts_stok.ReadOnly = true;
            this.txt_Cocuk_Ts_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Cocuk_Ts_stok.TabIndex = 43;
            this.txt_Cocuk_Ts_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_P_stok
            // 
            this.txt_Cocuk_P_stok.Location = new System.Drawing.Point(714, 269);
            this.txt_Cocuk_P_stok.Name = "txt_Cocuk_P_stok";
            this.txt_Cocuk_P_stok.ReadOnly = true;
            this.txt_Cocuk_P_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Cocuk_P_stok.TabIndex = 44;
            this.txt_Cocuk_P_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_STs_stok
            // 
            this.txt_Cocuk_STs_stok.Location = new System.Drawing.Point(714, 369);
            this.txt_Cocuk_STs_stok.Name = "txt_Cocuk_STs_stok";
            this.txt_Cocuk_STs_stok.ReadOnly = true;
            this.txt_Cocuk_STs_stok.Size = new System.Drawing.Size(180, 27);
            this.txt_Cocuk_STs_stok.TabIndex = 45;
            this.txt_Cocuk_STs_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // RafdakiStokForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 553);
            this.Controls.Add(this.txt_Cocuk_STs_stok);
            this.Controls.Add(this.txt_Cocuk_P_stok);
            this.Controls.Add(this.txt_Cocuk_Ts_stok);
            this.Controls.Add(this.txt_Kadin_STs_stok);
            this.Controls.Add(this.txt_Erkek_P_stok);
            this.Controls.Add(this.txt_Erkek_STs_stok);
            this.Controls.Add(this.txt_Kadin_Ts_stok);
            this.Controls.Add(this.txt_Kadin_P_stok);
            this.Controls.Add(this.txt_Erkek_Ts_stok);
            this.Controls.Add(this.lblPantolonn);
            this.Controls.Add(this.lblSweatshirtt);
            this.Controls.Add(this.lblTshirtt);
            this.Controls.Add(this.lblKadin);
            this.Controls.Add(this.lblCocuk);
            this.Controls.Add(this.lblErkek);
            this.Name = "RafdakiStokForm";
            this.Text = "RAFTAKİ STOK";
            this.Load += new System.EventHandler(this.RafdakiStokForm_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void RafdakiStokForm_Load1(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion
        public System.Windows.Forms.Label lblPantolonn;
        public System.Windows.Forms.Label lblSweatshirtt;
        public System.Windows.Forms.Label lblTshirtt;
        public System.Windows.Forms.Label lblKadin;
        public System.Windows.Forms.Label lblCocuk;
        public System.Windows.Forms.Label lblErkek;
        public System.Windows.Forms.TextBox txt_Erkek_Ts_stok;
        public System.Windows.Forms.TextBox txt_Kadin_P_stok;
        public System.Windows.Forms.TextBox txt_Kadin_Ts_stok;
        public System.Windows.Forms.TextBox txt_Erkek_STs_stok;
        public System.Windows.Forms.TextBox txt_Erkek_P_stok;
        public System.Windows.Forms.TextBox txt_Kadin_STs_stok;
        public System.Windows.Forms.TextBox txt_Cocuk_Ts_stok;
        public System.Windows.Forms.TextBox txt_Cocuk_P_stok;
        public System.Windows.Forms.TextBox txt_Cocuk_STs_stok;
    }
}