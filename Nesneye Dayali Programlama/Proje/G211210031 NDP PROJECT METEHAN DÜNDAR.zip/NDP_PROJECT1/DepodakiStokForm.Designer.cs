﻿
namespace NDP_PROJECT1
{
    partial class DepodakiStokForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtR_Cocuk_STs_stok = new System.Windows.Forms.TextBox();
            this.txtR_Cocuk_P_stok = new System.Windows.Forms.TextBox();
            this.txtR_Cocuk_Ts_stok = new System.Windows.Forms.TextBox();
            this.txtR_Kadin_STs_stok = new System.Windows.Forms.TextBox();
            this.txtR_Erkek_P_stok = new System.Windows.Forms.TextBox();
            this.txtR_Erkek_STs_stok = new System.Windows.Forms.TextBox();
            this.txtR_Kadin_Ts_stok = new System.Windows.Forms.TextBox();
            this.txtR_Kadin_P_stok = new System.Windows.Forms.TextBox();
            this.txtR_Erkek_Ts_stok = new System.Windows.Forms.TextBox();
            this.lblPantolonn = new System.Windows.Forms.Label();
            this.lblSweatshirtt = new System.Windows.Forms.Label();
            this.lblTshirtt = new System.Windows.Forms.Label();
            this.lblKadin = new System.Windows.Forms.Label();
            this.lblCocuk = new System.Windows.Forms.Label();
            this.lblErkek = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtR_Cocuk_STs_stok
            // 
            this.txtR_Cocuk_STs_stok.Location = new System.Drawing.Point(717, 395);
            this.txtR_Cocuk_STs_stok.Name = "txtR_Cocuk_STs_stok";
            this.txtR_Cocuk_STs_stok.ReadOnly = true;
            this.txtR_Cocuk_STs_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Cocuk_STs_stok.TabIndex = 60;
            this.txtR_Cocuk_STs_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Cocuk_P_stok
            // 
            this.txtR_Cocuk_P_stok.Location = new System.Drawing.Point(717, 295);
            this.txtR_Cocuk_P_stok.Name = "txtR_Cocuk_P_stok";
            this.txtR_Cocuk_P_stok.ReadOnly = true;
            this.txtR_Cocuk_P_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Cocuk_P_stok.TabIndex = 59;
            this.txtR_Cocuk_P_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Cocuk_Ts_stok
            // 
            this.txtR_Cocuk_Ts_stok.Location = new System.Drawing.Point(717, 181);
            this.txtR_Cocuk_Ts_stok.Name = "txtR_Cocuk_Ts_stok";
            this.txtR_Cocuk_Ts_stok.ReadOnly = true;
            this.txtR_Cocuk_Ts_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Cocuk_Ts_stok.TabIndex = 58;
            this.txtR_Cocuk_Ts_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Kadin_STs_stok
            // 
            this.txtR_Kadin_STs_stok.Location = new System.Drawing.Point(497, 395);
            this.txtR_Kadin_STs_stok.Name = "txtR_Kadin_STs_stok";
            this.txtR_Kadin_STs_stok.ReadOnly = true;
            this.txtR_Kadin_STs_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Kadin_STs_stok.TabIndex = 57;
            this.txtR_Kadin_STs_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Erkek_P_stok
            // 
            this.txtR_Erkek_P_stok.Location = new System.Drawing.Point(277, 295);
            this.txtR_Erkek_P_stok.Name = "txtR_Erkek_P_stok";
            this.txtR_Erkek_P_stok.ReadOnly = true;
            this.txtR_Erkek_P_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Erkek_P_stok.TabIndex = 56;
            this.txtR_Erkek_P_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Erkek_STs_stok
            // 
            this.txtR_Erkek_STs_stok.Location = new System.Drawing.Point(277, 395);
            this.txtR_Erkek_STs_stok.Name = "txtR_Erkek_STs_stok";
            this.txtR_Erkek_STs_stok.ReadOnly = true;
            this.txtR_Erkek_STs_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Erkek_STs_stok.TabIndex = 55;
            this.txtR_Erkek_STs_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Kadin_Ts_stok
            // 
            this.txtR_Kadin_Ts_stok.Location = new System.Drawing.Point(497, 181);
            this.txtR_Kadin_Ts_stok.Name = "txtR_Kadin_Ts_stok";
            this.txtR_Kadin_Ts_stok.ReadOnly = true;
            this.txtR_Kadin_Ts_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Kadin_Ts_stok.TabIndex = 54;
            this.txtR_Kadin_Ts_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Kadin_P_stok
            // 
            this.txtR_Kadin_P_stok.Location = new System.Drawing.Point(497, 295);
            this.txtR_Kadin_P_stok.Name = "txtR_Kadin_P_stok";
            this.txtR_Kadin_P_stok.ReadOnly = true;
            this.txtR_Kadin_P_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Kadin_P_stok.TabIndex = 53;
            this.txtR_Kadin_P_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtR_Erkek_Ts_stok
            // 
            this.txtR_Erkek_Ts_stok.Location = new System.Drawing.Point(277, 181);
            this.txtR_Erkek_Ts_stok.Name = "txtR_Erkek_Ts_stok";
            this.txtR_Erkek_Ts_stok.ReadOnly = true;
            this.txtR_Erkek_Ts_stok.Size = new System.Drawing.Size(180, 27);
            this.txtR_Erkek_Ts_stok.TabIndex = 52;
            this.txtR_Erkek_Ts_stok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPantolonn
            // 
            this.lblPantolonn.AutoSize = true;
            this.lblPantolonn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPantolonn.Location = new System.Drawing.Point(59, 281);
            this.lblPantolonn.Name = "lblPantolonn";
            this.lblPantolonn.Size = new System.Drawing.Size(170, 41);
            this.lblPantolonn.TabIndex = 51;
            this.lblPantolonn.Text = "PANTOLON";
            // 
            // lblSweatshirtt
            // 
            this.lblSweatshirtt.AutoSize = true;
            this.lblSweatshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSweatshirtt.Location = new System.Drawing.Point(60, 381);
            this.lblSweatshirtt.Name = "lblSweatshirtt";
            this.lblSweatshirtt.Size = new System.Drawing.Size(187, 41);
            this.lblSweatshirtt.TabIndex = 50;
            this.lblSweatshirtt.Text = "SWEATSHIRT";
            // 
            // lblTshirtt
            // 
            this.lblTshirtt.AutoSize = true;
            this.lblTshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTshirtt.Location = new System.Drawing.Point(60, 181);
            this.lblTshirtt.Name = "lblTshirtt";
            this.lblTshirtt.Size = new System.Drawing.Size(124, 41);
            this.lblTshirtt.TabIndex = 49;
            this.lblTshirtt.Text = "T-SHIRT";
            // 
            // lblKadin
            // 
            this.lblKadin.AutoSize = true;
            this.lblKadin.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblKadin.Location = new System.Drawing.Point(497, 56);
            this.lblKadin.Name = "lblKadin";
            this.lblKadin.Size = new System.Drawing.Size(180, 60);
            this.lblKadin.TabIndex = 48;
            this.lblKadin.Text = "KADIN";
            // 
            // lblCocuk
            // 
            this.lblCocuk.AutoSize = true;
            this.lblCocuk.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCocuk.Location = new System.Drawing.Point(717, 56);
            this.lblCocuk.Name = "lblCocuk";
            this.lblCocuk.Size = new System.Drawing.Size(180, 60);
            this.lblCocuk.TabIndex = 47;
            this.lblCocuk.Text = "ÇOCUK";
            // 
            // lblErkek
            // 
            this.lblErkek.AutoSize = true;
            this.lblErkek.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblErkek.Location = new System.Drawing.Point(277, 56);
            this.lblErkek.Name = "lblErkek";
            this.lblErkek.Size = new System.Drawing.Size(180, 60);
            this.lblErkek.TabIndex = 46;
            this.lblErkek.Text = "ERKEK";
            // 
            // DepodakiStokForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 553);
            this.Controls.Add(this.txtR_Cocuk_STs_stok);
            this.Controls.Add(this.txtR_Cocuk_P_stok);
            this.Controls.Add(this.txtR_Cocuk_Ts_stok);
            this.Controls.Add(this.txtR_Kadin_STs_stok);
            this.Controls.Add(this.txtR_Erkek_P_stok);
            this.Controls.Add(this.txtR_Erkek_STs_stok);
            this.Controls.Add(this.txtR_Kadin_Ts_stok);
            this.Controls.Add(this.txtR_Kadin_P_stok);
            this.Controls.Add(this.txtR_Erkek_Ts_stok);
            this.Controls.Add(this.lblPantolonn);
            this.Controls.Add(this.lblSweatshirtt);
            this.Controls.Add(this.lblTshirtt);
            this.Controls.Add(this.lblKadin);
            this.Controls.Add(this.lblCocuk);
            this.Controls.Add(this.lblErkek);
            this.Name = "DepodakiStokForm";
            this.Text = "DEPODAKİ STOK";
            this.Load += new System.EventHandler(this.RaftakiStokForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtR_Cocuk_STs_stok;
        public System.Windows.Forms.TextBox txtR_Cocuk_P_stok;
        public System.Windows.Forms.TextBox txtR_Cocuk_Ts_stok;
        public System.Windows.Forms.TextBox txtR_Kadin_STs_stok;
        public System.Windows.Forms.TextBox txtR_Erkek_P_stok;
        public System.Windows.Forms.TextBox txtR_Erkek_STs_stok;
        public System.Windows.Forms.TextBox txtR_Kadin_Ts_stok;
        public System.Windows.Forms.TextBox txtR_Kadin_P_stok;
        public System.Windows.Forms.TextBox txtR_Erkek_Ts_stok;
        public System.Windows.Forms.Label lblPantolonn;
        public System.Windows.Forms.Label lblSweatshirtt;
        public System.Windows.Forms.Label lblTshirtt;
        public System.Windows.Forms.Label lblKadin;
        public System.Windows.Forms.Label lblCocuk;
        public System.Windows.Forms.Label lblErkek;
    }
}