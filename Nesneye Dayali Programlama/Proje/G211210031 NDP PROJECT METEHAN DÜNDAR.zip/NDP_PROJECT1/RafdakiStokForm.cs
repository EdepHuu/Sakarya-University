﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NDP_PROJECT1
{
    public partial class RafdakiStokForm : Form
    {
        public RafdakiStokForm()
        {
            InitializeComponent();
        }

        private void lblE_ts_stok_Click(object sender, EventArgs e)
        {

        }

        private void lblK_ts_stok_Click(object sender, EventArgs e)
        {

        }

        private void RafdakiStokForm_Load_1(object sender, EventArgs e)
        {

        }

        private void lblKadin_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void texttxt_Kadin_Ts_stokBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Erkek_Ts_stok_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
