﻿
namespace NDP_PROJECT1
{
    partial class TedarikciForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Cocuk_STs_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_P_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Cocuk_Ts_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Kadin_STs_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Kadin_P_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Kadin_Ts_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Erkek_STs_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Erkek_P_Siparis = new System.Windows.Forms.TextBox();
            this.txt_Erkek_Ts_Siparis = new System.Windows.Forms.TextBox();
            this.lbl_Cocuk_STs_Stok = new System.Windows.Forms.Label();
            this.lbl_Cocuk_P_Stok = new System.Windows.Forms.Label();
            this.lbl_Cocuk_Ts_Stok = new System.Windows.Forms.Label();
            this.lbl_Kadin_STs_Stok = new System.Windows.Forms.Label();
            this.lbl_Kadin_P_Stok = new System.Windows.Forms.Label();
            this.lbl_Kadin_Ts_Stok = new System.Windows.Forms.Label();
            this.lbl_Erkek_STs_Stok = new System.Windows.Forms.Label();
            this.lbl_Erkek_P_Stok = new System.Windows.Forms.Label();
            this.lbl_Erkek_Ts_Stok = new System.Windows.Forms.Label();
            this.lblSiparis3 = new System.Windows.Forms.Label();
            this.lblstok3 = new System.Windows.Forms.Label();
            this.lblSiparis2 = new System.Windows.Forms.Label();
            this.lblstok2 = new System.Windows.Forms.Label();
            this.lblSiparis1 = new System.Windows.Forms.Label();
            this.lblstok1 = new System.Windows.Forms.Label();
            this.lblPantolonn = new System.Windows.Forms.Label();
            this.lblSweatshirtt = new System.Windows.Forms.Label();
            this.lblTshirtt = new System.Windows.Forms.Label();
            this.lblKadin = new System.Windows.Forms.Label();
            this.lblCocuk = new System.Windows.Forms.Label();
            this.lblErkek = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Cocuk_STs_Siparis
            // 
            this.txt_Cocuk_STs_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Cocuk_STs_Siparis.Location = new System.Drawing.Point(809, 369);
            this.txt_Cocuk_STs_Siparis.Name = "txt_Cocuk_STs_Siparis";
            this.txt_Cocuk_STs_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Cocuk_STs_Siparis.TabIndex = 61;
            this.txt_Cocuk_STs_Siparis.Text = "0";
            this.txt_Cocuk_STs_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_P_Siparis
            // 
            this.txt_Cocuk_P_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Cocuk_P_Siparis.Location = new System.Drawing.Point(809, 269);
            this.txt_Cocuk_P_Siparis.Name = "txt_Cocuk_P_Siparis";
            this.txt_Cocuk_P_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Cocuk_P_Siparis.TabIndex = 60;
            this.txt_Cocuk_P_Siparis.Text = "0";
            this.txt_Cocuk_P_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Cocuk_Ts_Siparis
            // 
            this.txt_Cocuk_Ts_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Cocuk_Ts_Siparis.Location = new System.Drawing.Point(809, 170);
            this.txt_Cocuk_Ts_Siparis.Name = "txt_Cocuk_Ts_Siparis";
            this.txt_Cocuk_Ts_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Cocuk_Ts_Siparis.TabIndex = 59;
            this.txt_Cocuk_Ts_Siparis.Text = "0";
            this.txt_Cocuk_Ts_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_STs_Siparis
            // 
            this.txt_Kadin_STs_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Kadin_STs_Siparis.Location = new System.Drawing.Point(589, 370);
            this.txt_Kadin_STs_Siparis.Name = "txt_Kadin_STs_Siparis";
            this.txt_Kadin_STs_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Kadin_STs_Siparis.TabIndex = 58;
            this.txt_Kadin_STs_Siparis.Text = "0";
            this.txt_Kadin_STs_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_P_Siparis
            // 
            this.txt_Kadin_P_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Kadin_P_Siparis.Location = new System.Drawing.Point(589, 269);
            this.txt_Kadin_P_Siparis.Name = "txt_Kadin_P_Siparis";
            this.txt_Kadin_P_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Kadin_P_Siparis.TabIndex = 57;
            this.txt_Kadin_P_Siparis.Text = "0";
            this.txt_Kadin_P_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Kadin_Ts_Siparis
            // 
            this.txt_Kadin_Ts_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Kadin_Ts_Siparis.Location = new System.Drawing.Point(589, 169);
            this.txt_Kadin_Ts_Siparis.Name = "txt_Kadin_Ts_Siparis";
            this.txt_Kadin_Ts_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Kadin_Ts_Siparis.TabIndex = 56;
            this.txt_Kadin_Ts_Siparis.Text = "0";
            this.txt_Kadin_Ts_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Erkek_STs_Siparis
            // 
            this.txt_Erkek_STs_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Erkek_STs_Siparis.Location = new System.Drawing.Point(369, 369);
            this.txt_Erkek_STs_Siparis.Name = "txt_Erkek_STs_Siparis";
            this.txt_Erkek_STs_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Erkek_STs_Siparis.TabIndex = 55;
            this.txt_Erkek_STs_Siparis.Text = "0";
            this.txt_Erkek_STs_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Erkek_P_Siparis
            // 
            this.txt_Erkek_P_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Erkek_P_Siparis.Location = new System.Drawing.Point(369, 269);
            this.txt_Erkek_P_Siparis.Name = "txt_Erkek_P_Siparis";
            this.txt_Erkek_P_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Erkek_P_Siparis.TabIndex = 54;
            this.txt_Erkek_P_Siparis.Text = "0";
            this.txt_Erkek_P_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Erkek_Ts_Siparis
            // 
            this.txt_Erkek_Ts_Siparis.BackColor = System.Drawing.Color.White;
            this.txt_Erkek_Ts_Siparis.Location = new System.Drawing.Point(369, 169);
            this.txt_Erkek_Ts_Siparis.Name = "txt_Erkek_Ts_Siparis";
            this.txt_Erkek_Ts_Siparis.Size = new System.Drawing.Size(103, 27);
            this.txt_Erkek_Ts_Siparis.TabIndex = 53;
            this.txt_Erkek_Ts_Siparis.Text = "0";
            this.txt_Erkek_Ts_Siparis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_Cocuk_STs_Stok
            // 
            this.lbl_Cocuk_STs_Stok.AutoSize = true;
            this.lbl_Cocuk_STs_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Cocuk_STs_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cocuk_STs_Stok.Location = new System.Drawing.Point(732, 369);
            this.lbl_Cocuk_STs_Stok.Name = "lbl_Cocuk_STs_Stok";
            this.lbl_Cocuk_STs_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Cocuk_STs_Stok.TabIndex = 52;
            this.lbl_Cocuk_STs_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Cocuk_P_Stok
            // 
            this.lbl_Cocuk_P_Stok.AutoSize = true;
            this.lbl_Cocuk_P_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Cocuk_P_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cocuk_P_Stok.Location = new System.Drawing.Point(732, 269);
            this.lbl_Cocuk_P_Stok.Name = "lbl_Cocuk_P_Stok";
            this.lbl_Cocuk_P_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Cocuk_P_Stok.TabIndex = 51;
            this.lbl_Cocuk_P_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Cocuk_Ts_Stok
            // 
            this.lbl_Cocuk_Ts_Stok.AutoSize = true;
            this.lbl_Cocuk_Ts_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Cocuk_Ts_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cocuk_Ts_Stok.Location = new System.Drawing.Point(732, 169);
            this.lbl_Cocuk_Ts_Stok.Name = "lbl_Cocuk_Ts_Stok";
            this.lbl_Cocuk_Ts_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Cocuk_Ts_Stok.TabIndex = 50;
            this.lbl_Cocuk_Ts_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Kadin_STs_Stok
            // 
            this.lbl_Kadin_STs_Stok.AutoSize = true;
            this.lbl_Kadin_STs_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Kadin_STs_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Kadin_STs_Stok.Location = new System.Drawing.Point(512, 369);
            this.lbl_Kadin_STs_Stok.Name = "lbl_Kadin_STs_Stok";
            this.lbl_Kadin_STs_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Kadin_STs_Stok.TabIndex = 49;
            this.lbl_Kadin_STs_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Kadin_P_Stok
            // 
            this.lbl_Kadin_P_Stok.AutoSize = true;
            this.lbl_Kadin_P_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Kadin_P_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Kadin_P_Stok.Location = new System.Drawing.Point(512, 269);
            this.lbl_Kadin_P_Stok.Name = "lbl_Kadin_P_Stok";
            this.lbl_Kadin_P_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Kadin_P_Stok.TabIndex = 48;
            this.lbl_Kadin_P_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Kadin_Ts_Stok
            // 
            this.lbl_Kadin_Ts_Stok.AutoSize = true;
            this.lbl_Kadin_Ts_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Kadin_Ts_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Kadin_Ts_Stok.Location = new System.Drawing.Point(512, 169);
            this.lbl_Kadin_Ts_Stok.Name = "lbl_Kadin_Ts_Stok";
            this.lbl_Kadin_Ts_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Kadin_Ts_Stok.TabIndex = 47;
            this.lbl_Kadin_Ts_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Erkek_STs_Stok
            // 
            this.lbl_Erkek_STs_Stok.AutoSize = true;
            this.lbl_Erkek_STs_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Erkek_STs_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Erkek_STs_Stok.Location = new System.Drawing.Point(292, 369);
            this.lbl_Erkek_STs_Stok.Name = "lbl_Erkek_STs_Stok";
            this.lbl_Erkek_STs_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Erkek_STs_Stok.TabIndex = 46;
            this.lbl_Erkek_STs_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Erkek_P_Stok
            // 
            this.lbl_Erkek_P_Stok.AutoSize = true;
            this.lbl_Erkek_P_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Erkek_P_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Erkek_P_Stok.Location = new System.Drawing.Point(292, 269);
            this.lbl_Erkek_P_Stok.Name = "lbl_Erkek_P_Stok";
            this.lbl_Erkek_P_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Erkek_P_Stok.TabIndex = 45;
            this.lbl_Erkek_P_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Erkek_Ts_Stok
            // 
            this.lbl_Erkek_Ts_Stok.AutoSize = true;
            this.lbl_Erkek_Ts_Stok.BackColor = System.Drawing.Color.White;
            this.lbl_Erkek_Ts_Stok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Erkek_Ts_Stok.Location = new System.Drawing.Point(292, 169);
            this.lbl_Erkek_Ts_Stok.Name = "lbl_Erkek_Ts_Stok";
            this.lbl_Erkek_Ts_Stok.Size = new System.Drawing.Size(0, 28);
            this.lbl_Erkek_Ts_Stok.TabIndex = 44;
            this.lbl_Erkek_Ts_Stok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSiparis3
            // 
            this.lblSiparis3.AutoSize = true;
            this.lblSiparis3.BackColor = System.Drawing.Color.White;
            this.lblSiparis3.Location = new System.Drawing.Point(809, 108);
            this.lblSiparis3.Name = "lblSiparis3";
            this.lblSiparis3.Size = new System.Drawing.Size(103, 20);
            this.lblSiparis3.TabIndex = 43;
            this.lblSiparis3.Text = "Siparis Sayiniz";
            // 
            // lblstok3
            // 
            this.lblstok3.AutoSize = true;
            this.lblstok3.BackColor = System.Drawing.Color.White;
            this.lblstok3.Location = new System.Drawing.Point(732, 108);
            this.lblstok3.Name = "lblstok3";
            this.lblstok3.Size = new System.Drawing.Size(79, 20);
            this.lblstok3.TabIndex = 42;
            this.lblstok3.Text = "Stok Sayisi";
            // 
            // lblSiparis2
            // 
            this.lblSiparis2.AutoSize = true;
            this.lblSiparis2.BackColor = System.Drawing.Color.White;
            this.lblSiparis2.Location = new System.Drawing.Point(589, 108);
            this.lblSiparis2.Name = "lblSiparis2";
            this.lblSiparis2.Size = new System.Drawing.Size(103, 20);
            this.lblSiparis2.TabIndex = 41;
            this.lblSiparis2.Text = "Siparis Sayiniz";
            // 
            // lblstok2
            // 
            this.lblstok2.AutoSize = true;
            this.lblstok2.BackColor = System.Drawing.Color.White;
            this.lblstok2.Location = new System.Drawing.Point(512, 108);
            this.lblstok2.Name = "lblstok2";
            this.lblstok2.Size = new System.Drawing.Size(79, 20);
            this.lblstok2.TabIndex = 40;
            this.lblstok2.Text = "Stok Sayisi";
            // 
            // lblSiparis1
            // 
            this.lblSiparis1.AutoSize = true;
            this.lblSiparis1.BackColor = System.Drawing.Color.White;
            this.lblSiparis1.Location = new System.Drawing.Point(369, 108);
            this.lblSiparis1.Name = "lblSiparis1";
            this.lblSiparis1.Size = new System.Drawing.Size(103, 20);
            this.lblSiparis1.TabIndex = 39;
            this.lblSiparis1.Text = "Siparis Sayiniz";
            // 
            // lblstok1
            // 
            this.lblstok1.AutoSize = true;
            this.lblstok1.BackColor = System.Drawing.Color.White;
            this.lblstok1.Location = new System.Drawing.Point(292, 108);
            this.lblstok1.Name = "lblstok1";
            this.lblstok1.Size = new System.Drawing.Size(79, 20);
            this.lblstok1.TabIndex = 38;
            this.lblstok1.Text = "Stok Sayisi";
            // 
            // lblPantolonn
            // 
            this.lblPantolonn.AutoSize = true;
            this.lblPantolonn.BackColor = System.Drawing.Color.White;
            this.lblPantolonn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPantolonn.Location = new System.Drawing.Point(74, 259);
            this.lblPantolonn.Name = "lblPantolonn";
            this.lblPantolonn.Size = new System.Drawing.Size(170, 41);
            this.lblPantolonn.TabIndex = 37;
            this.lblPantolonn.Text = "PANTOLON";
            // 
            // lblSweatshirtt
            // 
            this.lblSweatshirtt.AutoSize = true;
            this.lblSweatshirtt.BackColor = System.Drawing.Color.White;
            this.lblSweatshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSweatshirtt.Location = new System.Drawing.Point(75, 359);
            this.lblSweatshirtt.Name = "lblSweatshirtt";
            this.lblSweatshirtt.Size = new System.Drawing.Size(187, 41);
            this.lblSweatshirtt.TabIndex = 36;
            this.lblSweatshirtt.Text = "SWEATSHIRT";
            // 
            // lblTshirtt
            // 
            this.lblTshirtt.AutoSize = true;
            this.lblTshirtt.BackColor = System.Drawing.Color.White;
            this.lblTshirtt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTshirtt.Location = new System.Drawing.Point(75, 159);
            this.lblTshirtt.Name = "lblTshirtt";
            this.lblTshirtt.Size = new System.Drawing.Size(124, 41);
            this.lblTshirtt.TabIndex = 35;
            this.lblTshirtt.Text = "T-SHIRT";
            // 
            // lblKadin
            // 
            this.lblKadin.AutoSize = true;
            this.lblKadin.BackColor = System.Drawing.Color.White;
            this.lblKadin.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblKadin.Location = new System.Drawing.Point(512, 34);
            this.lblKadin.Name = "lblKadin";
            this.lblKadin.Size = new System.Drawing.Size(180, 60);
            this.lblKadin.TabIndex = 34;
            this.lblKadin.Text = "KADIN";
            // 
            // lblCocuk
            // 
            this.lblCocuk.AutoSize = true;
            this.lblCocuk.BackColor = System.Drawing.Color.White;
            this.lblCocuk.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCocuk.Location = new System.Drawing.Point(732, 34);
            this.lblCocuk.Name = "lblCocuk";
            this.lblCocuk.Size = new System.Drawing.Size(180, 60);
            this.lblCocuk.TabIndex = 33;
            this.lblCocuk.Text = "ÇOCUK";
            // 
            // lblErkek
            // 
            this.lblErkek.AutoSize = true;
            this.lblErkek.BackColor = System.Drawing.Color.White;
            this.lblErkek.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblErkek.Location = new System.Drawing.Point(292, 34);
            this.lblErkek.Name = "lblErkek";
            this.lblErkek.Size = new System.Drawing.Size(180, 60);
            this.lblErkek.TabIndex = 32;
            this.lblErkek.Text = "ERKEK";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("SimSun-ExtB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(437, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(337, 87);
            this.button1.TabIndex = 31;
            this.button1.Text = "Siparis Al ve Stoga Ekle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TedarikciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1171, 553);
            this.Controls.Add(this.txt_Cocuk_STs_Siparis);
            this.Controls.Add(this.txt_Cocuk_P_Siparis);
            this.Controls.Add(this.txt_Cocuk_Ts_Siparis);
            this.Controls.Add(this.txt_Kadin_STs_Siparis);
            this.Controls.Add(this.txt_Kadin_P_Siparis);
            this.Controls.Add(this.txt_Kadin_Ts_Siparis);
            this.Controls.Add(this.txt_Erkek_STs_Siparis);
            this.Controls.Add(this.txt_Erkek_P_Siparis);
            this.Controls.Add(this.txt_Erkek_Ts_Siparis);
            this.Controls.Add(this.lbl_Cocuk_STs_Stok);
            this.Controls.Add(this.lbl_Cocuk_P_Stok);
            this.Controls.Add(this.lbl_Cocuk_Ts_Stok);
            this.Controls.Add(this.lbl_Kadin_STs_Stok);
            this.Controls.Add(this.lbl_Kadin_P_Stok);
            this.Controls.Add(this.lbl_Kadin_Ts_Stok);
            this.Controls.Add(this.lbl_Erkek_STs_Stok);
            this.Controls.Add(this.lbl_Erkek_P_Stok);
            this.Controls.Add(this.lbl_Erkek_Ts_Stok);
            this.Controls.Add(this.lblSiparis3);
            this.Controls.Add(this.lblstok3);
            this.Controls.Add(this.lblSiparis2);
            this.Controls.Add(this.lblstok2);
            this.Controls.Add(this.lblSiparis1);
            this.Controls.Add(this.lblstok1);
            this.Controls.Add(this.lblPantolonn);
            this.Controls.Add(this.lblSweatshirtt);
            this.Controls.Add(this.lblTshirtt);
            this.Controls.Add(this.lblKadin);
            this.Controls.Add(this.lblCocuk);
            this.Controls.Add(this.lblErkek);
            this.Controls.Add(this.button1);
            this.Name = "TedarikciForm";
            this.Text = "TedarikciForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txt_Cocuk_STs_Siparis;
        public System.Windows.Forms.TextBox txt_Cocuk_P_Siparis;
        public System.Windows.Forms.TextBox txt_Cocuk_Ts_Siparis;
        public System.Windows.Forms.TextBox txt_Kadin_STs_Siparis;
        public System.Windows.Forms.TextBox txt_Kadin_P_Siparis;
        public System.Windows.Forms.TextBox txt_Kadin_Ts_Siparis;
        public System.Windows.Forms.TextBox txt_Erkek_STs_Siparis;
        public System.Windows.Forms.TextBox txt_Erkek_P_Siparis;
        public System.Windows.Forms.TextBox txt_Erkek_Ts_Siparis;
        public System.Windows.Forms.Label lbl_Cocuk_STs_Stok;
        public System.Windows.Forms.Label lbl_Cocuk_P_Stok;
        public System.Windows.Forms.Label lbl_Cocuk_Ts_Stok;
        public System.Windows.Forms.Label lbl_Kadin_STs_Stok;
        public System.Windows.Forms.Label lbl_Kadin_P_Stok;
        public System.Windows.Forms.Label lbl_Kadin_Ts_Stok;
        public System.Windows.Forms.Label lbl_Erkek_STs_Stok;
        public System.Windows.Forms.Label lbl_Erkek_P_Stok;
        public System.Windows.Forms.Label lbl_Erkek_Ts_Stok;
        public System.Windows.Forms.Label lblSiparis3;
        public System.Windows.Forms.Label lblstok3;
        public System.Windows.Forms.Label lblSiparis2;
        public System.Windows.Forms.Label lblstok2;
        public System.Windows.Forms.Label lblSiparis1;
        public System.Windows.Forms.Label lblstok1;
        public System.Windows.Forms.Label lblPantolonn;
        public System.Windows.Forms.Label lblSweatshirtt;
        public System.Windows.Forms.Label lblTshirtt;
        public System.Windows.Forms.Label lblKadin;
        public System.Windows.Forms.Label lblCocuk;
        public System.Windows.Forms.Label lblErkek;
        public System.Windows.Forms.Button button1;
    }
}